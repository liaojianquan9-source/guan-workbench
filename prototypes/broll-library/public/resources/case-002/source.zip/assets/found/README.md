# Found production assets

## `problem-technology-workspace-unsplash-p-xSl33Wxyc.jpg`

- Purpose: single replaceable background for `problem-background`.
- Photo: “two black computer monitors on black table”.
- Author: Farzad (`euwars`).
- Source: <https://unsplash.com/photos/two-black-computer-monitors-on-black-table-p-xSl33Wxyc>
- License: <https://unsplash.com/license>
- Provenance record: `evidence/asset-sources/problem-background.json`.
- The image contains no visible person and is not a frame, screenshot, or crop from the reference video.
